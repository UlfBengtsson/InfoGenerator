﻿using InfoGenerator.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace InfoGenerator.Models
{
    public class PersonalInfoGen : IPersonalInfoGen
    {
        string[] fNames = new string[] { "Anna", "Mia", "Lena", "Ann-Sofia", "Maria" };
        string[] mNames = new string[] { "Hans-Olof", "Ola", "Clars", "Ulf", "Sven" };
        string[] lNames = new string[] { "Svensson", "Anderson", "Bengtsson", "Karlsson", "Gustavsson" };

        public Gender RandomGender()
        {
            if (IPersonalInfoGen.randomNumberGen.Next(2) == 1)
            {
                return Gender.Female;
            }
            else
            {
                return Gender.Male;
            }
            //throw new NotImplementedException();
        }

        public string[] FemaleFirstNames()
        {
            return fNames;
            //throw new NotImplementedException();
        }

        public string[] MaleFirstNames()
        {
            return mNames;
            //throw new NotImplementedException();
        }

        public string[] LastNames()
        {
            return lNames;
        }

        public string LastName()
        {
            return lNames[IPersonalInfoGen.randomNumberGen.Next(lNames.Length)];
            //throw new NotImplementedException();
        }

        public List<string> LastNames(int amount)
        {
            List<string> names = new List<string>();

            for (int i = 0; i < amount; i++)
            {

                names.Add(lNames[IPersonalInfoGen.randomNumberGen.Next(lNames.Length)]);

            }

            return names;
            //throw new NotImplementedException();
        }

        public string FirstName()
        {
            if (RandomGender() == Gender.Female)
            {
                return fNames[IPersonalInfoGen.randomNumberGen.Next(fNames.Length)];
            }
            else
            {
                return mNames[IPersonalInfoGen.randomNumberGen.Next(mNames.Length)];
            }
            //throw new NotImplementedException();
        }

        public string FirstName(Gender gender)
        {
            if (gender == Gender.Female)
            {
                return fNames[IPersonalInfoGen.randomNumberGen.Next(fNames.Length)];
            }
            else
            {
                return mNames[IPersonalInfoGen.randomNumberGen.Next(mNames.Length)];
            }
            //throw new NotImplementedException();
        }

        public List<string> FirstNames(int amount)
        {
            List<string> names = new List<string>();

            for (int i = 0; i < amount; i++)
            {
                names.Add(FirstName());
            }

            return names;
            //throw new NotImplementedException();
        }

        public List<string> FirstNames(int amount, Gender gender)
        {
            List<string> names = new List<string>();

            for (int i = 0; i < amount; i++)
            {
                names.Add(FirstName(gender));
            }

            return names;
            //throw new NotImplementedException();
        }

        public string FullName()
        {
            string fullName = null;
            if (RandomGender() == Gender.Female)
            {
                fullName = fNames[IPersonalInfoGen.randomNumberGen.Next(fNames.Length)];
            }
            else
            {
                fullName = mNames[IPersonalInfoGen.randomNumberGen.Next(mNames.Length)];
            }

            fullName += ' ' + lNames[IPersonalInfoGen.randomNumberGen.Next(lNames.Length)];

            return fullName;
            //throw new NotImplementedException();
        }

        public string FullName(Gender gender)
        {
            string fullName = null;
            if (gender == Gender.Female)
            {
                fullName = fNames[IPersonalInfoGen.randomNumberGen.Next(fNames.Length)];
            }
            else
            {
                fullName = mNames[IPersonalInfoGen.randomNumberGen.Next(mNames.Length)];
            }

            fullName += ' ' + lNames[IPersonalInfoGen.randomNumberGen.Next(lNames.Length)];

            return fullName;
            //throw new NotImplementedException();
        }

        public List<string> FullNames(int amount)
        {
            List<string> names = new List<string>();

            for (int i = 0; i < amount; i++)
            {
                names.Add(FullName());
            }

            return names;
            //throw new NotImplementedException();
        }

        public List<string> FullNames(int amount, Gender gender)
        {
            List<string> names = new List<string>();

            for (int i = 0; i < amount; i++)
            {
                names.Add(FullName(gender));
            }

            return names;
            //throw new NotImplementedException();
        }

        public Dictionary<Gender, List<string>> GenderSplitedFullNames(int amountOfNames, bool perGender)
        {
            Dictionary<Gender, List<string>> dict = new Dictionary<Gender, List<string>>();

            int maleCount = 0;
            int femaleCount = 0;

            if (perGender)
            {
                maleCount = amountOfNames;
                femaleCount = amountOfNames;
            }
            else
            {
                maleCount = IPersonalInfoGen.randomNumberGen.Next(amountOfNames + 1);
                femaleCount = amountOfNames - maleCount;
            }

            dict.Add(Gender.Male, FullNames(maleCount, Gender.Male));
            dict.Add(Gender.Female, FullNames(femaleCount, Gender.Female));

            return dict;
            //throw new NotImplementedException();
        }

    }
}
